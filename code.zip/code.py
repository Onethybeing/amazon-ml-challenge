# %%
import torch, platform, psutil, time
from datetime import datetime
print("\n===== SYSTEM INFO =====")
print("Python version:", platform.python_version())
print("Platform:", platform.platform())
print("Processor:", platform.processor())
print("Logical CPUs:", psutil.cpu_count(logical=True))
print("Physical cores:", psutil.cpu_count(logical=False))
print("RAM (GB):", round(psutil.virtual_memory().total / (1024**3), 2))

if torch.cuda.is_available():
    print("\n===== GPU DETECTED =====")
    print("GPU Name:", torch.cuda.get_device_name(0))
    print("CUDA Version:", torch.version.cuda)
else:
    print("\nNo GPU detected. Running on CPU.")

# Smart Product Pricing - Jupyter-friendly end-to-end script
# Save this as smart_pricing_jupyter.py or paste into a Jupyter cell and run step-by-step.
# Requirements: Python 3.8+, torch, torchvision, tqdm, pandas, numpy, scikit-learn, lightgbm, joblib, pillow, requests
# If running on GPU-enabled env, PyTorch will use CUDA automatically.

import os
import re
import time
import math
import json
import random
import shutil
import requests
from io import BytesIO
from PIL import Image
from concurrent.futures import ThreadPoolExecutor
from tqdm.auto import tqdm

import numpy as np
import pandas as pd

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from scipy import sparse

import lightgbm as lgb
import joblib

import torch
import torch.nn as nn
import torchvision.transforms as T
import torchvision.models as models


# ------------------------ CONFIG ------------------------
DATA_DIR = r"C:\Users\VICTUS\Desktop\ML Challenge"
TRAIN_CSV = os.path.join(DATA_DIR, "train_csv.csv")
TEST_CSV = os.path.join(DATA_DIR, "sample_test_csv.csv")
OUTPUT_CSV = "test_out.csv"
IMAGE_DIR = r"C:\Users\VICTUS\Desktop\ML Challenge\downloaded"
IMAGE_BATCH_FEATURES = "image_features.npy"
SEED = 42
N_THREADS = 12
MAX_TFIDF_FEATURES = 40000
TARGET_COL = "price"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
print("Using device:", DEVICE)


# ------------------------ UTILITIES ------------------------

def set_seed(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed()


def safe_mkdir(path):
    os.makedirs(path, exist_ok=True)


# Robust image downloader with retries

def download_image(url, dest_path, timeout=8, max_retries=3):
    if not isinstance(url, str) or not url:
        return False
    for attempt in range(max_retries):
        try:
            resp = requests.get(url, timeout=timeout)
            if resp.status_code == 200:
                with open(dest_path, "wb") as f:
                    f.write(resp.content)
                return True
        except Exception:
            time.sleep(0.5 + attempt * 0.5)
    return False



def download_images(df, link_col="image_link", id_col="sample_id", outdir=IMAGE_DIR, n_threads=N_THREADS, force=False):
    safe_mkdir(outdir)
    tasks = []
    for i, row in df[[id_col, link_col]].iterrows():
        sid = str(row[id_col])
        link = row[link_col]
        fname = f"{sid}.jpg"
        dest = os.path.join(outdir, fname)
        if os.path.exists(dest) and not force:
            continue
        tasks.append((link, dest))

    with ThreadPoolExecutor(max_workers=n_threads) as exe:
        futures = [exe.submit(download_image, link, dest) for (link, dest) in tasks]
        for f in tqdm(futures, total=len(futures), desc="Downloading images"):
            try:
                f.result()
            except Exception:
                pass

# ------------------------ DATA LOADING & PREPROCESSING ------------------------


def load_data(train_path=TRAIN_CSV, test_path=TEST_CSV):
    print("Loading data...")
    train = pd.read_csv(train_path)
    test = pd.read_csv(test_path)
    return train, test


# Basic text cleaning and IPQ extraction (Item Pack Quantity often in catalog_content)

def clean_text(s):
    if pd.isna(s):
        return ""
    s = str(s)
    s = s.replace('\n', ' ').replace('\r', ' ')
    s = re.sub(r"http\S+", " ", s)
    s = re.sub(r"[^\x00-\x7F]+"," ", s)  # remove non-ascii noise
    s = re.sub(r"\s+", " ", s).strip().lower()
    return s


def extract_ipq(s):
    # naive numeric extraction for pack qty like 'Pack of 2', '2 Pack', '4 pcs', '100-count'
    if pd.isna(s):
        return 1
    s = str(s).lower()
    # common patterns
    patterns = [r"(\d+)\s*[-]?[p]ack", r"(\d+)\s*pack", r"(\d+)\s*pcs", r"(\d+)\s*pieces",
                r"(\d+)\s*count", r"(\d+)\s*x\b", r"(\d+)[-]count", r"(\d+)\s*ct\b"]
    for pat in patterns:
        m = re.search(pat, s)
        if m:
            try:
                val = int(m.group(1))
                if val > 0 and val < 10000:
                    return val
            except:
                pass
    # fallback: look for any small integer
    m = re.search(r"\b(\d{1,3})\b", s)
    if m:
        v = int(m.group(1))
        if v > 1 and v < 1000:
            return v
    return 1


# ------------------------ TEXT FEATURES ------------------------


def fit_text_vectorizer(texts, max_features=MAX_TFIDF_FEATURES):
    print("Fitting TF-IDF on text...")
    vect = TfidfVectorizer(max_features=max_features, ngram_range=(1,2), min_df=3)
    vect.fit(texts)
    return vect

# ------------------------ IMAGE EMBEDDINGS ------------------------


def build_image_model(device=DEVICE):
    # Use a pretrained model (resnet50) and remove final classifier
    model = models.resnet50(pretrained=True)
    # remove final fc
    modules = list(model.children())[:-1]
    backbone = nn.Sequential(*modules)
    backbone.eval()
    backbone.to(device)
    return backbone


def image_transform():
    return T.Compose([
        T.Resize((224,224)),
        T.ToTensor(),
        T.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])
    ])


def extract_image_features(df, id_col='sample_id', image_dir=IMAGE_DIR, model=None, batch_size=64, device=DEVICE, save_path=IMAGE_BATCH_FEATURES):
    if model is None:
        model = build_image_model(device)
    transform = image_transform()
    ids = df[id_col].astype(str).tolist()
    features = np.zeros((len(ids), 2048), dtype=np.float32)

    with torch.no_grad():
        for i in tqdm(range(0, len(ids), batch_size), desc='Image feature batches'):
            batch_ids = ids[i:i+batch_size]
            imgs = []
            for sid in batch_ids:
                p = os.path.join(image_dir, f"{sid}.jpg")
                if os.path.exists(p):
                    try:
                        img = Image.open(p).convert('RGB')
                    except Exception:
                        img = Image.new('RGB', (224,224), color=(255,255,255))
                else:
                    img = Image.new('RGB', (224,224), color=(255,255,255))
                imgs.append(transform(img))
            batch_tensor = torch.stack(imgs).to(device)
            out = model(batch_tensor)
            out = out.view(out.size(0), -1).cpu().numpy()
            features[i:i+len(batch_ids), :] = out
    np.save(save_path, features)
    return features








# ------------------------ MODEL TRAINING ------------------------

def prepare_features(train_df, test_df, vectorizer=None, image_features_train=None, image_features_test=None):
    # Basic feature set: IPQ, text tfidf, image embeddings (numpy arrays)
    print("Preparing features...")
    # Clean text
    for df in [train_df, test_df]:
        df['catalog_clean'] = df['catalog_content'].fillna('').astype(str).map(clean_text)
        df['ipq'] = df['catalog_content'].map(extract_ipq).fillna(1).astype(float)

    texts = pd.concat([train_df['catalog_clean'], test_df['catalog_clean']])
    if vectorizer is None:
        vectorizer = fit_text_vectorizer(texts)
    X_text_train = vectorizer.transform(train_df['catalog_clean'])
    X_text_test = vectorizer.transform(test_df['catalog_clean'])

    # scale ipq
    scaler = StandardScaler()
    ipq_train = scaler.fit_transform(train_df[['ipq']].values)
    ipq_test = scaler.transform(test_df[['ipq']].values)

    # image features
    if image_features_train is None:
        if os.path.exists(IMAGE_BATCH_FEATURES):
            image_features = np.load(IMAGE_BATCH_FEATURES)
        else:
            image_features = None
    else:
        image_features = image_features_train

    # if image_features exist and length matches
    if image_features is not None and image_features.shape[0] == train_df.shape[0]:
        img_train = image_features
    else:
        img_train = np.zeros((train_df.shape[0], 2048), dtype=np.float32)

    if image_features_test is not None and image_features_test.shape[0] == test_df.shape[0]:
        img_test = image_features_test
    else:
        img_test = np.zeros((test_df.shape[0], 2048), dtype=np.float32)

    # combine sparse and dense
    X_train = sparse.hstack([X_text_train, sparse.csr_matrix(ipq_train), sparse.csr_matrix(img_train)]).tocsr()
    X_test = sparse.hstack([X_text_test, sparse.csr_matrix(ipq_test), sparse.csr_matrix(img_test)]).tocsr()

    return X_train, X_test, vectorizer, scaler


def smape(y_true, y_pred):
    denom = (np.abs(y_true) + np.abs(y_pred)) / 2.0
    mask = denom == 0
    denom[mask] = 1.0
    res = np.abs(y_true - y_pred) / denom
    return np.mean(res) * 100.0


def train_lgbm(X, y, X_val=None, y_val=None, params=None, num_boost_round=1000):
    default_params = {
        'objective': 'regression',
        'metric': 'l2',
        'learning_rate': 0.05,
        'num_leaves': 127,
        'min_data_in_leaf': 20,
        'verbosity': -1,
        'n_jobs': 4,
        'seed': SEED
    }
    if params:
        default_params.update(params)
    dtrain = lgb.Dataset(X, label=y)
    valid_sets = [dtrain]
    valid_names = ['train']
    if X_val is not None:
        dval = lgb.Dataset(X_val, label=y_val)
        valid_sets.append(dval)
        valid_names.append('val')
    model = lgb.train(
        default_params,
        dtrain,
        num_boost_round=num_boost_round,
        valid_sets=valid_sets,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50),
            lgb.log_evaluation(period=50)
        ]
    )

    return model






# ------------------------ MAIN PIPELINE ------------------------
def main():
    # Load
    train, test = load_data()

    # Download images for both train and test (be patient; throttling possible)
    print("Downloading train images (this may take a while)...")
    download_images(train, link_col='image_link', id_col='sample_id', outdir=IMAGE_DIR, n_threads=N_THREADS)
    print("Downloading test images...")
    download_images(test, link_col='image_link', id_col='sample_id', outdir=IMAGE_DIR, n_threads=N_THREADS)

    # Extract image features for train and test separately and save
    if not os.path.exists(IMAGE_BATCH_FEATURES):
        print("Extracting image features for train+test (this may take long and uses GPU if available)...")
        # concatenate train+test frames with sample_id unique order to generate features aligning to both
        combined = pd.concat([train[['sample_id']], test[['sample_id']]], ignore_index=True)
        img_model = build_image_model(DEVICE)
        features = extract_image_features(combined, id_col='sample_id', image_dir=IMAGE_DIR, model=img_model, batch_size=64, device=DEVICE, save_path=IMAGE_BATCH_FEATURES)
    else:
        features = np.load(IMAGE_BATCH_FEATURES)

    # split features
    img_train = features[:train.shape[0], :]
    img_test = features[train.shape[0]:, :]

    # prepare features (text + ipq + image)
    X_train_full, X_test_full, vect, scaler = prepare_features(train, test, vectorizer=None, image_features_train=img_train, image_features_test=img_test)

    # label transform
    y = train[TARGET_COL].fillna(0).values
    # remove non-positive labels (if dataset guarantees positive, skip)
    pos_mask = y > 0
    X_train_filtered = X_train_full[pos_mask]
    y_filtered = y[pos_mask]
    # log transform to stabilize
    y_log = np.log1p(y_filtered)

    # holdout
    X_tr, X_val, y_tr, y_val = train_test_split(X_train_filtered, y_log, test_size=0.15, random_state=SEED)

    # train
    model = train_lgbm(X_tr, y_tr, X_val=X_val, y_val=y_val, num_boost_round=1000)

    # validation predictions
    val_pred_log = model.predict(X_val)
    val_pred = np.expm1(val_pred_log)
    y_val_true = np.expm1(y_val)
    print("Validation SMAPE:", smape(y_val_true, val_pred))

    # full train on all data
    print("Retraining on full data...")
    model_full = train_lgbm(X_train_filtered, y_log, num_boost_round=model.best_iteration)

    # predict test
    test_pred_log = model_full.predict(X_test_full)
    test_pred = np.expm1(test_pred_log)

    # ensure positive floats
    test_pred = np.clip(test_pred, 0.01, None)

    # write output
    out = pd.DataFrame({
        'sample_id': test['sample_id'],
        'price': test_pred
    })
    out.to_csv(OUTPUT_CSV, index=False)
    print(f"Saved predictions to {OUTPUT_CSV}")

    # save models and artifacts
    safe_mkdir('artifacts')
    joblib.dump(model_full, os.path.join('artifacts','lgbm_model.joblib'))
    joblib.dump(vect, os.path.join('artifacts','tfidf_vectorizer.joblib'))
    joblib.dump(scaler, os.path.join('artifacts','ipq_scaler.joblib'))
    print("Saved artifacts to artifacts/")


if __name__ == '__main__':
    main()






# %% Produce predictions for large dataset (~75k)
import os, time, random, re
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import BytesIO
from PIL import Image
import requests
import joblib
import numpy as np
import pandas as pd
from tqdm.auto import tqdm
from scipy import sparse

import torch
import torch.nn as nn
import torchvision.models as models
import torchvision.transforms as T

# ---------------- CONFIG - edit paths if needed ----------------
BIG_CSV_PATH = r"C:\Users\VICTUS\Desktop\ML Challenge\test_csv.csv"   # <-- your 75k file
ARTIFACT_DIR = "artifacts"
MODEL_PATH   = os.path.join(ARTIFACT_DIR, "lgbm_model.joblib")
VECT_PATH    = os.path.join(ARTIFACT_DIR, "tfidf_vectorizer.joblib")
SCALER_PATH  = os.path.join(ARTIFACT_DIR, "ipq_scaler.joblib")
IMAGE_DIR    = r"C:\Users\VICTUS\Desktop\ML Challenge\downloaded_big"
IMG_FEAT_MEMMAP = os.path.join(ARTIFACT_DIR, "big_img_feats.dat")  # memmap file
IMG_FEAT_SHAPE_NPY = os.path.join(ARTIFACT_DIR, "big_img_feats_shape.npy")  # store shape (n, dim)
OUTPUT_CSV   = "final_predictions.csv"

SEED = 42
N_THREADS = 20
IMG_DIMS = 2048   # must match training embedding length
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DOWNLOAD_TIMEOUT = 8
MAX_RETRIES = 3
IMG_BATCH = 256   # batch size during image embedding extraction
PREDICT_CHUNK = 5000  # number of rows to predict per chunk (adjust for memory)

print("DEVICE:", DEVICE)

# ---------------- utilities ----------------
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
if DEVICE.startswith("cuda"):
    torch.cuda.manual_seed_all(SEED)

def safe_mkdir(p): 
    os.makedirs(p, exist_ok=True)

safe_mkdir(IMAGE_DIR)
safe_mkdir(ARTIFACT_DIR)

def clean_text(s):
    if pd.isna(s): return ""
    s = str(s).replace('\n',' ').replace('\r',' ')
    s = re.sub(r"http\S+", " ", s)
    s = re.sub(r"[^\x00-\x7F]+"," ", s)
    s = re.sub(r"\s+", " ", s).strip().lower()
    return s

def extract_ipq(s):
    if pd.isna(s): return 1
    s = str(s).lower()
    patterns = [r"(\d+)\s*[-]?[p]ack", r"(\d+)\s*pack", r"(\d+)\s*pcs", r"(\d+)\s*pieces",
                r"(\d+)\s*count", r"(\d+)\s*x\b", r"(\d+)[-]count", r"(\d+)\s*ct\b"]
    for pat in patterns:
        m = re.search(pat, s)
        if m:
            try:
                val = int(m.group(1))
                if 0 < val < 10000: return val
            except:
                pass
    m = re.search(r"\b(\d{1,3})\b", s)
    if m:
        v = int(m.group(1))
        if 1 < v < 1000: return v
    return 1

# ---------------- image downloader ----------------
def download_image(url, dest_path, timeout=DOWNLOAD_TIMEOUT, max_retries=MAX_RETRIES):
    if not isinstance(url, str) or not url:
        return False
    for attempt in range(max_retries):
        try:
            resp = requests.get(url, timeout=timeout)
            if resp.status_code == 200:
                with open(dest_path, "wb") as f:
                    f.write(resp.content)
                return True
        except Exception:
            time.sleep(0.5 + attempt * 0.5)
    return False

def download_images_from_df(df, link_col='image_link', id_col='sample_id', outdir=IMAGE_DIR, n_threads=N_THREADS):
    tasks = []
    for _, row in df[[id_col, link_col]].iterrows():
        sid = str(row[id_col])
        link = row[link_col] if pd.notna(row[link_col]) else ""
        dest = os.path.join(outdir, f"{sid}.jpg")
        if os.path.exists(dest):
            continue
        tasks.append((link, dest))
    if not tasks:
        print("No images to download (already present or links empty).")
        return
    with ThreadPoolExecutor(max_workers=n_threads) as exe:
        futures = {exe.submit(download_image, link, dest): (link, dest) for (link,dest) in tasks}
        for f in tqdm(as_completed(futures), total=len(futures), desc="Downloading images"):
            try:
                _ = f.result()
            except Exception:
                pass

# ---------------- image model & extractor ----------------
def build_image_model(device=DEVICE):
    model = models.resnet50(pretrained=True)
    modules = list(model.children())[:-1]
    backbone = nn.Sequential(*modules)
    backbone.eval()
    backbone.to(device)
    return backbone

def image_transform():
    return T.Compose([
        T.Resize((224,224)),
        T.ToTensor(),
        T.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225])
    ])

def extract_and_write_memmap(id_list, image_dir=IMAGE_DIR, memmap_path=IMG_FEAT_MEMMAP, shape_path=IMG_FEAT_SHAPE_NPY,
                            img_dim=IMG_DIMS, batch_size=IMG_BATCH, device=DEVICE):
    n = len(id_list)
    # create memmap file on disk (float32)
    # We will create a raw binary memmap with shape (n,img_dim)
    # If memmap exists and shape matches, we will reuse it
    reuse = False
    if os.path.exists(shape_path) and os.path.exists(memmap_path):
        try:
            existing_shape = np.load(shape_path)
            if existing_shape[0] == n and existing_shape[1] == img_dim:
                reuse = True
        except Exception:
            reuse = False

    if reuse:
        print("Existing memmap features found and shape matches; reusing:", memmap_path)
        return np.memmap(memmap_path, dtype='float32', mode='r+', shape=(n, img_dim))
    # create/overwrite memmap
    print("Creating memmap for image features:", memmap_path)
    mm = np.memmap(memmap_path, dtype='float32', mode='w+', shape=(n, img_dim))
    transform = image_transform()
    model = build_image_model(device)
    with torch.no_grad():
        for start in tqdm(range(0, n, batch_size), desc="Extracting image embeddings"):
            end = min(n, start + batch_size)
            batch_ids = id_list[start:end]
            imgs = []
            for sid in batch_ids:
                p = os.path.join(image_dir, f"{sid}.jpg")
                if os.path.exists(p):
                    try:
                        img = Image.open(p).convert('RGB')
                    except Exception:
                        img = Image.new('RGB', (224,224), color=(255,255,255))
                else:
                    img = Image.new('RGB', (224,224), color=(255,255,255))
                imgs.append(transform(img))
            batch_tensor = torch.stack(imgs).to(device)
            out = model(batch_tensor)
            out = out.view(out.size(0), -1).cpu().numpy().astype('float32')
            mm[start:end, :] = out
            # flush to disk
            mm.flush()
    # save shape for reuse detection
    np.save(shape_path, np.array([n, img_dim]))
    return np.memmap(memmap_path, dtype='float32', mode='r+', shape=(n, img_dim))

# ---------------- prediction chunker ----------------
def predict_in_chunks(df, id_col='sample_id', text_col='catalog_clean', ipq_col='ipq',
                      img_memmap=None, vect=None, scaler=None, model=None, chunk_size=PREDICT_CHUNK):
    n = df.shape[0]
    results = []
    for start in range(0, n, chunk_size):
        end = min(n, start + chunk_size)
        sub = df.iloc[start:end].reset_index(drop=True)
        # text vectorize
        X_text = vect.transform(sub[text_col])
        # ipq scale
        ipq_scaled = scaler.transform(sub[[ipq_col]].values)
        # image features slice
        img_slice = np.array(img_memmap[start:end, :], dtype='float32')
        # combine (sparse + ipq + dense image)
        X_chunk = sparse.hstack([X_text, sparse.csr_matrix(ipq_scaled), sparse.csr_matrix(img_slice)]).tocsr()
        pred_log = model.predict(X_chunk)
        pred = np.expm1(pred_log)   # inverse of log1p used in training; if raw use pred_log
        pred = np.clip(pred, 0.01, None)
        results.append(pd.DataFrame({id_col: sub[id_col].values, 'price': pred}))
        print(f"Predicted rows {start} to {end}")
    return pd.concat(results, ignore_index=True)

# ---------------- main flow ----------------
print("Loading model artifacts...")
model = joblib.load(MODEL_PATH)
vect = joblib.load(VECT_PATH)
scaler = joblib.load(SCALER_PATH)

print("Loading big CSV...")
df = pd.read_csv(BIG_CSV_PATH)
print("Rows:", df.shape[0], "Columns:", df.shape[1])

# normalize names
if 'sample_id' not in df.columns:
    possible = [c for c in df.columns if 'id' in c.lower()]
    if possible:
        df.rename(columns={possible[0]:'sample_id'}, inplace=True)
    else:
        df['sample_id'] = df.index.astype(str)

if 'catalog_content' not in df.columns:
    possible = [c for c in df.columns if 'catalog' in c.lower() or 'desc' in c.lower() or 'description' in c.lower()]
    if possible:
        df.rename(columns={possible[0]:'catalog_content'}, inplace=True)
    else:
        df['catalog_content'] = ""

if 'image_link' not in df.columns:
    possible = [c for c in df.columns if 'image' in c.lower() or 'img' in c.lower() or 'link' in c.lower()]
    if possible:
        df.rename(columns={possible[0]:'image_link'}, inplace=True)
    else:
        df['image_link'] = ""

# prepare text and ipq columns (cheap, done in-memory)
print("Cleaning text and extracting IPQ (fast) ...")
df['catalog_clean'] = df['catalog_content'].fillna('').astype(str).map(clean_text)
df['ipq'] = df['catalog_content'].map(extract_ipq).fillna(1).astype(float)

# download images for entire dataset (only missing ones)
print("Downloading images (multi-threaded) ...")
download_images_from_df(df, link_col='image_link', id_col='sample_id', outdir=IMAGE_DIR, n_threads=N_THREADS)

# extract image features into memmap (disk-backed)
id_list = df['sample_id'].astype(str).tolist()
print("Extracting image features (will use disk-backed memmap) ...")
img_memmap = extract_and_write_memmap(id_list, image_dir=IMAGE_DIR, memmap_path=IMG_FEAT_MEMMAP,
                                     shape_path=IMG_FEAT_SHAPE_NPY, img_dim=IMG_DIMS, batch_size=IMG_BATCH, device=DEVICE)

# Predict in chunks and write final CSV
print("Predicting in chunks ...")
pred_df = predict_in_chunks(df, id_col='sample_id', text_col='catalog_clean', ipq_col='ipq',
                            img_memmap=img_memmap, vect=vect, scaler=scaler, model=model, chunk_size=PREDICT_CHUNK)

# Save final CSV with two columns: sample_id, price
pred_df = pred_df[['sample_id', 'price']]
pred_df.to_csv(OUTPUT_CSV, index=False)
print("Saved final predictions to", OUTPUT_CSV)
